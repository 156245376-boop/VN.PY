# obs   (层级:L1)

## 职责

结构化日志、State_Snapshot 写入、告警推送(R20/R21)。

## 公开接口

必须与 `__init__.py` 的 `__all__` 完全一致,由 `tests/test_docs_contract.py` 强制(R26.6)。

_本模块尚未实现,`__all__` 为空。_

## 不变式

以下设计已确定,运行实现于 Phase 2 落地(ADR-0018):

- recorder/live 的每个实例各有独立快照、临时文件、事件流和告警确认文件,每份只由一个写入者更新。
- 快照携带 role、instance_id、boot_id、序号与心跳;一个实例心跳不能掩盖另一个失联。
- Monitor 仅读合并;告警确认由独立 CLI 控制入口交给本模块持久化,不修改已有事件记录。
- 通道/进程整体故障独立告警,不从全部合约没 Tick 推导无成交。

## 禁止 import

- **不得 import 策略、委托、数据库** —— 可观测性是横切关注点。反向依赖会使日志模块参与业务,进而无法在任意位置调用

## 为什么这么设计

见 [`docs/IMPLEMENTATION_PLAN.md`](../../docs/IMPLEMENTATION_PLAN.md) 与 `docs/adr/`。本模块于 Phase 2 落地。

## 否决过的方案

_待 Phase 2 实施时填写。_ 事后补写不出当时的约束与否决理由,但提前编造更糟。

## 已知局限

_待 Phase 2 实施时填写。_ 事后补写不出当时的约束与否决理由,但提前编造更糟。

## 测试

```powershell
.venv\Scripts\python.exe -m pytest tests/obs -q
```
