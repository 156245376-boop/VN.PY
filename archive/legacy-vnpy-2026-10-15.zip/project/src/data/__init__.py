"""data (L3) —— 采集、存储、聚合、质量校验、主力连续序列构造(R4–R10/R25/R28)。

公开接口、不变式与禁止 import 见同目录 README.md。
本模块于 Phase 3(存储/聚合/质量)/ Phase 4(回填/连续) 落地,当前为 Phase 0 存根。
"""

__all__: list[str] = []
