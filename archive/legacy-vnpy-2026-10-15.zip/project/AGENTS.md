# 项目工作约定

开始修改前阅读 `CLAUDE.md`；需求真相来源为
`.kiro/specs/vnpy-futures-trading-system/requirements.md`。

底层设计以当前需求、`docs/IMPLEMENTATION_PLAN.md` 和 ADR-0016 至 ADR-0019 为准。
历史 ADR 已注明细节修订，不恢复旧的撤单即重报、在线 DuckDB 跨进程读写、共享快照
或“目标等于已成交”假设。后续阶段实现状态见 `docs/DESIGN_REVIEW.md`。

修改后执行 `tools/check.ps1`。公开接口、模块 README 与架构记录同时更新。
市场事实测试的待填预期值由开发者依据外部资料核对，不照抄实现输出。
