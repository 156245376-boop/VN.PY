# qf：国内期货交易与回测系统

个人自用、Windows 单机部署，行情与交易接入基于 vn.py / CTP。

当前完成 Phase 0 骨架和 Phase 1 的 `core` / `meta` 代码。市场事实尚待人工核对，
其余模块与交易命令仍为存根。当前版本不能录制、回测或实盘交易。

## 新机器安装与迁移

需要 Git、PowerShell、uv，以及 64 位 CPython 3.13.11。
在仓库根目录运行：

```powershell
uv python install 3.13.11
uv sync --locked --extra dev
.\tools\check.ps1
.venv\Scripts\python.exe -m apps.cli --help
```

`.python-version` 固定解释器版本，`pyproject.toml` 固定直接依赖，`uv.lock` 固定传递依赖
与下载哈希。`--locked` 会在依赖配置与锁文件不一致时停止，避免迁移时悄悄重新选版本。

迁移时重新创建 `.venv`；虚拟环境中的解释器、命令启动器和 editable 安装带有绝对路径，
不能把复制的环境当作可移植安装。若旧环境存在，先将它改名留存，再执行上述安装命令。
`data/`、`results/` 和 `conf/local.toml` 不在 Git 中，需要单独迁移；其中 `data/raw/`
的自录行情不可重建。凭证模板见 [`conf/local.toml.template`](conf/local.toml.template)。

## 检查结果的含义

日常统一执行 `tools/check.ps1`，它从仓库根运行并设置 Windows UTF-8 环境。
门禁要求普通用例全部通过，待核对用例全部因 R34.7 守卫失败；收集错误、中断、
其他异常、跳过或部分通过均不会放行。单独运行全部 `pytest` 当前会失败，这是待核对
状态的明确提示。门禁通过不表示市场规则已核对或交易功能已完成。

## 项目资料

- [`CLAUDE.md`](CLAUDE.md)：仓库地图、模块职责与硬约束。
- [`docs/REVIEW_ME.md`](docs/REVIEW_ME.md)：审阅顺序与已知风险。
- [需求文档](.kiro/specs/vnpy-futures-trading-system/requirements.md)：需求真相来源。
- [`docs/IMPLEMENTATION_PLAN.md`](docs/IMPLEMENTATION_PLAN.md)：分阶段实施计划。
- [`docs/DEPENDENCIES.md`](docs/DEPENDENCIES.md)：CTP、Python 与依赖版本依据。
- [`docs/MIGRATION_REVIEW.md`](docs/MIGRATION_REVIEW.md)：本次迁移检查与待办。
- [`docs/DESIGN_REVIEW.md`](docs/DESIGN_REVIEW.md)：十项底层设计修订、触发例子与后续实现门槛。
