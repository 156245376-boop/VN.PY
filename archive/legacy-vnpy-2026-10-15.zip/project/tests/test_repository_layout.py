"""以构建配置为准检查迁移完整性,避免缺失模块被动态发现逻辑静默漏掉。"""

from __future__ import annotations

import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def test_all_declared_packages_and_their_contracts_exist() -> None:
    config = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    packages = config["tool"]["hatch"]["build"]["targets"]["wheel"]["packages"]
    for package in packages:
        directory = ROOT / package
        assert (directory / "__init__.py").is_file(), f"缺失构建包: {package}"
        assert (directory / "README.md").is_file(), f"缺失模块契约: {package}"
        assert (ROOT / "tests" / directory.name).is_dir(), f"缺失测试目录: {package}"
