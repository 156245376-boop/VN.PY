"""校验待核对用例确实全部因 R34.7 守卫失败,而非因运行故障退出。"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from xml.etree import ElementTree

_GUARD_REASON = "预期值待人工核对填入(R34.7):"
_SETUP_MESSAGE = f'failed on setup with "Failed: {_GUARD_REASON}'


def validate_report(path: Path, exit_code: int) -> int:
    """返回待核对用例数;退出码、统计或失败原因不符合契约时拒绝。"""
    if exit_code not in (1, 5):
        raise ValueError(f"pytest 退出码 {exit_code} 不是待核对失败或无用例")
    root = ElementTree.parse(path).getroot()
    if root.tag != "testsuites":
        raise ValueError("不是 pytest JUnit 报告")
    suites = root.findall("testsuite")
    if not suites:
        raise ValueError("JUnit 报告缺少 testsuite")
    count = 0
    for suite in suites:
        cases = suite.findall("testcase")
        expected = len(cases)
        statistics = {"tests": expected, "errors": expected, "failures": 0, "skipped": 0}
        for key, value in statistics.items():
            if int(suite.attrib[key]) != value:
                raise ValueError(f"待核对用例并未全部由 setup 守卫拒绝: {key}")
        for case in cases:
            outcomes = list(case)
            errors = case.findall("error")
            if len(errors) != 1 or any(node.tag in {"failure", "skipped"} for node in outcomes):
                raise ValueError(f"{case.get('name')} 没有唯一的守卫失败结果")
            error = errors[0]
            if not error.get("message", "").startswith(_SETUP_MESSAGE) or not (
                error.text or ""
            ).startswith(_GUARD_REASON):
                raise ValueError(f"{case.get('name')} 因其他错误失败,不是 R34.7 守卫")
        count += expected
    if (exit_code == 5) != (count == 0):
        raise ValueError("pytest 退出码与报告中的用例数不一致")
    return count


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("report", type=Path)
    parser.add_argument("exit_code", type=int)
    args = parser.parse_args()
    try:
        count = validate_report(args.report, args.exit_code)
    except (OSError, ValueError, KeyError, ElementTree.ParseError) as exc:
        print(f"pending_expected 门禁失败: {exc}", file=sys.stderr)
        return 1
    if count:
        print(f"{count} 个待核对用例全部因 R34.7 守卫失败;市场事实仍未完成核对。")
    else:
        print("没有待核对用例。")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
