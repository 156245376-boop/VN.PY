# runtime   (层级:L8)

## 职责

实盘会话装配、状态持久化、持仓对账、交易日调度、到期换月强平(R16/R18/R31)。

## 公开接口

必须与 `__init__.py` 的 `__all__` 完全一致,由 `tests/test_docs_contract.py` 强制(R26.6)。

_本模块尚未实现,`__all__` 为空。_

## 不变式

以下设计已确定,运行实现于 Phase 6 落地(ADR-0016):

- 一处账户执行者推进准入、预留、委托和成交;登录前取得 account_id/environment 独占锁。
- 每个实际合约至多归一个实例,停止后未平持仓/未决委托仍保留归属。
- state.db 同一事务提交委托事件、CTP 关联、Fill.identity 去重、账本和冻结变换;JSONL 为可重建副本。
- submitting 恢复为 unknown 并核实,缺回报或查询未见不能单独证明未送达。
- flatten/强平覆盖跨重启保存,换月按旧腿已确认成交推进;旧目标不得重新开仓。
- 查询窗口与推送不能证明一致切面时保持不可信并冻结开仓,不以旧查询回滚新成交。

## 禁止 import

本层负责汇合其下全部层级,没有额外的禁止导入项。`engines` 与 `gateway` 同属 L7 且互不导入,只能由本层汇合;该约束由 `.importlinter` 强制。

## 为什么这么设计

见 [`docs/IMPLEMENTATION_PLAN.md`](../../docs/IMPLEMENTATION_PLAN.md) 与 `docs/adr/`。本模块于 Phase 6 落地。

## 否决过的方案

_待 Phase 6 实施时填写。_ 事后补写不出当时的约束与否决理由,但提前编造更糟。

## 已知局限

_待 Phase 6 实施时填写。_ 事后补写不出当时的约束与否决理由,但提前编造更糟。

## 测试

```powershell
.venv\Scripts\python.exe -m pytest tests/runtime -q
```
