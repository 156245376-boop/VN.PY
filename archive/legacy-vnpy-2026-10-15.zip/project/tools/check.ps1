# Deterministic verification entry point (R34.3).
# Keep this file ASCII so Windows PowerShell 5.1 can parse it without a BOM.
[CmdletBinding()]
param()

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$python = Join-Path $root ".venv\Scripts\python.exe"

$env:PYTHONUTF8 = "1"
$env:PYTHONIOENCODING = "utf-8"

if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
    throw "Project Python not found. See README.md for environment setup."
}

function Invoke-Check {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name,
        [Parameter(Mandatory = $true)]
        [scriptblock]$Command
    )

    Write-Host "`n=== $Name ===" -ForegroundColor Cyan
    & $Command
    if ($LASTEXITCODE -ne 0) {
        throw "$Name failed with exit code $LASTEXITCODE"
    }
}

Push-Location $root
try {
    Invoke-Check "pytest (verified cases)" { & $python -m pytest -m "not pending_expected" }

    # R34.7 requires tests whose expected values await manual verification to FAIL.
    # Verify EVERY selected case failed for the guard's reason. A collection error,
    # interruption, ordinary exception, skip, or partial green run must not pass.
    Write-Host "`n=== pytest (R34.7: pending_expected must fail) ===" -ForegroundColor Cyan
    $report = Join-Path $root (".pytest_cache\pending-" + [guid]::NewGuid() + ".xml")
    try {
        $pending = & $python -m pytest -m "pending_expected" --no-header -q "--junitxml=$report" 2>&1
        $pendingExit = $LASTEXITCODE
        & $python tools\check_pending_report.py $report $pendingExit
        if ($LASTEXITCODE -ne 0) {
            Write-Host ($pending -join "`n")
            throw "pending_expected verification failed"
        }
    }
    finally {
        if (Test-Path -LiteralPath $report) {
            Remove-Item -LiteralPath $report
        }
    }

    # Module invocation avoids console launchers with a stale absolute venv path.
    Invoke-Check "ruff" { & $python -m ruff check src tests tools }
    Invoke-Check "mypy" { & $python -m mypy src }
    Invoke-Check "import-linter" {
        & $python -c "from importlinter.cli import lint_imports_command; lint_imports_command()"
    }
    Invoke-Check "ac-coverage-markers" { & $python tools\requirements_coverage.py --summary }
    Write-Host "`nAll deterministic checks passed." -ForegroundColor Green
}
finally {
    Pop-Location
}
