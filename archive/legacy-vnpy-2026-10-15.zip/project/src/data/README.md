# data   (层级:L3)

## 职责

采集、市场数据存储、聚合、质量校验、主力连续序列构造(R4–R10/R25/R28)。策略状态、参考事实与告警记录分别由 runtime、meta、obs 持有。

## 公开接口

必须与 `__init__.py` 的 `__all__` 完全一致,由 `tests/test_docs_contract.py` 强制(R26.6)。

_本模块尚未实现,`__all__` 为空。_

## 不变式

以下设计已确定,运行实现按 Phase 2/3/4 落地(ADR-0017、ADR-0018):

- Raw 批次有稳定 chunk_id,重放不重复;全市场原始 Bar/决策批次与白名单 Tick 分别保留。
- Curated 发布新不可变文件与完整清单,只切换 latest 小指针,不覆盖非空目录或仍被引用的旧文件。
- 录制器独占在线 DuckDB,构建等待释放;回测/研究用内存 DuckDB 查询固定清单内文件。
- 无下一 Tick 也按 Clock 关闭分钟;关闭后不修改实时决策批次,迟到数据留 Raw。
- 缺口保留采集证据及未知状态;主力不能单独证明其他合约无成交。

## 禁止 import

- **不得 import vnpy —— 唯一例外是 `data/vnpy_db.py`** —— 该文件是供 vnpy 回测引擎读 Bar 的垫片(A5),隔离在单个叶子文件内使存储层可被自研引擎复用
- **不得 import 策略、委托、风控、实盘** —— 数据层不知道数据被谁使用
- **不得持有策略状态、参考事实或告警记录** —— 它们的所有者分别是 runtime、meta、obs;混入 Data_Store 会造成状态所有权重叠

## 为什么这么设计

见 [`docs/IMPLEMENTATION_PLAN.md`](../../docs/IMPLEMENTATION_PLAN.md) 与 `docs/adr/`。本模块于 Phase 3(存储/聚合/质量)/ Phase 4(回填/连续) 落地。

## 否决过的方案

_待 Phase 3(存储/聚合/质量)/ Phase 4(回填/连续) 实施时填写。_ 事后补写不出当时的约束与否决理由,但提前编造更糟。

## 已知局限

_待 Phase 3(存储/聚合/质量)/ Phase 4(回填/连续) 实施时填写。_ 事后补写不出当时的约束与否决理由,但提前编造更糟。

## 测试

```powershell
.venv\Scripts\python.exe -m pytest tests/data -q
```
