"""待核对门禁不能把 pytest 自身故障或部分通过当作符合 R34.7。"""

from __future__ import annotations

from pathlib import Path
from xml.etree import ElementTree

import pytest
from tools.check_pending_report import validate_report

_REASON = "预期值待人工核对填入(R34.7):需外部公告"


def _report(tmp_path: Path, outcomes: list[str]) -> Path:
    root = ElementTree.Element("testsuites")
    suite = ElementTree.SubElement(
        root,
        "testsuite",
        tests=str(len(outcomes)),
        errors=str(outcomes.count("guard") + outcomes.count("error")),
        failures=str(outcomes.count("failure")),
        skipped=str(outcomes.count("skipped")),
    )
    for index, outcome in enumerate(outcomes):
        case = ElementTree.SubElement(suite, "testcase", name=f"test_{index}")
        if outcome == "guard":
            error = ElementTree.SubElement(
                case, "error", message=f'failed on setup with "Failed: {_REASON}"'
            )
            error.text = _REASON
        elif outcome != "passed":
            ElementTree.SubElement(case, outcome, message="ordinary failure").text = "故障"
    path = tmp_path / "pending.xml"
    ElementTree.ElementTree(root).write(path, encoding="utf-8")
    return path


def test_every_pending_case_must_fail_for_guard_reason(tmp_path: Path) -> None:
    assert validate_report(_report(tmp_path, ["guard", "guard"]), 1) == 2


@pytest.mark.parametrize("outcome", ["passed", "error", "failure", "skipped"])
def test_partial_guard_failure_does_not_hide_other_outcomes(tmp_path: Path, outcome: str) -> None:
    with pytest.raises(ValueError):
        validate_report(_report(tmp_path, ["guard", outcome]), 1)


@pytest.mark.parametrize("exit_code", [0, 2, 3, 4, 5])
def test_invalid_exit_cannot_reuse_a_successful_report(tmp_path: Path, exit_code: int) -> None:
    with pytest.raises(ValueError):
        validate_report(_report(tmp_path, ["guard"]), exit_code)


def test_no_pending_cases_requires_empty_report_and_exit_five(tmp_path: Path) -> None:
    path = _report(tmp_path, [])
    assert validate_report(path, 5) == 0
    with pytest.raises(ValueError):
        validate_report(path, 1)


def test_missing_report_is_rejected(tmp_path: Path) -> None:
    with pytest.raises(OSError):
        validate_report(tmp_path / "absent.xml", 1)


def test_invalid_report_is_rejected(tmp_path: Path) -> None:
    path = tmp_path / "broken.xml"
    path.write_text("<testsuites>", encoding="utf-8")
    with pytest.raises(ElementTree.ParseError):
        validate_report(path, 1)


def test_wrong_setup_reason_is_rejected(tmp_path: Path) -> None:
    path = _report(tmp_path, ["guard"])
    root = ElementTree.parse(path)
    error = root.find("./testsuite/testcase/error")
    assert error is not None
    error.set("message", "failed on teardown")
    root.write(path, encoding="utf-8")
    with pytest.raises(ValueError):
        validate_report(path, 1)
